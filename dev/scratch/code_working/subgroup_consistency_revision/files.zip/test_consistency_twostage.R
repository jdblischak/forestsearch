#' @title Test and Benchmark Two-Stage Consistency Evaluation
#'
#' @description
#' This script demonstrates the two-stage sequential consistency evaluation
#' algorithm and benchmarks it against the original fixed-sample approach.
#'
#' @details
#' Run this script to:
#' 1. Verify the two-stage algorithm produces equivalent results
#' 2. Measure performance improvements
#' 3. Understand the algorithm's behavior with different scenarios

# =============================================================================
# SETUP
# =============================================================================

library(survival)
library(data.table)

# Source the new functions (adjust path as needed)
# source("R/subgroup_consistency_twostage.R")

# =============================================================================
# SECTION 1: UNIT TESTS FOR HELPER FUNCTIONS
# =============================================================================

test_wilson_ci <- function() {
  cat("\n=== Testing Wilson CI ===\n")

  # Test basic functionality
  ci <- wilson_ci(45, 50, 0.95)
  cat("45/50 successes:\n")
  cat("  Estimate:", round(ci["estimate"], 4), "(expected: 0.9)\n")
  cat("  95% CI: [", round(ci["lower"], 4), ", ", round(ci["upper"], 4), "]\n")

  # Test edge cases
  ci_zero <- wilson_ci(0, 50, 0.95)
  cat("0/50 successes: CI = [", round(ci_zero["lower"], 4), ", ",
      round(ci_zero["upper"], 4), "]\n")

  ci_all <- wilson_ci(50, 50, 0.95)
  cat("50/50 successes: CI = [", round(ci_all["lower"], 4), ", ",
      round(ci_all["upper"], 4), "]\n")

  ci_empty <- wilson_ci(0, 0, 0.95)
  cat("0/0 (empty): estimate =", ci_empty["estimate"], "\n")

  cat("Wilson CI tests: PASSED\n")
}


test_early_stop_decision <- function() {
  cat("\n=== Testing Early Stop Decision ===\n")

  # Clear pass (95% with tight CI)
  decision1 <- early_stop_decision(48, 50, threshold = 0.90)
  cat("48/50 vs 0.90 threshold:", decision1, "(expected: pass)\n")

  # Clear fail
  decision2 <- early_stop_decision(35, 50, threshold = 0.90)
  cat("35/50 vs 0.90 threshold:", decision2, "(expected: fail)\n")

  # Borderline - need more data
  decision3 <- early_stop_decision(44, 50, threshold = 0.90)
  cat("44/50 vs 0.90 threshold:", decision3, "(expected: continue)\n")

  # Not enough samples
  decision4 <- early_stop_decision(9, 10, threshold = 0.90, min_samples = 20)
  cat("9/10 with min_samples=20:", decision4, "(expected: continue)\n")

  cat("Early stop decision tests: PASSED\n")
}


test_calc_screen_threshold <- function() {
  cat("\n=== Testing Screen Threshold Calculation ===\n")

  scenarios <- list(
    list(pcons = 0.90, n = 30, desc = "90% threshold, 30 splits"),
    list(pcons = 0.95, n = 30, desc = "95% threshold, 30 splits"),
    list(pcons = 0.90, n = 50, desc = "90% threshold, 50 splits"),
    list(pcons = 0.85, n = 30, desc = "85% threshold, 30 splits")
  )

  for (s in scenarios) {
    thresh <- calc_screen_threshold(s$pcons, s$n)
    margin <- s$pcons - thresh
    cat(sprintf("%s: %.3f (margin: %.3f)\n", s$desc, thresh, margin))
  }

  cat("Screen threshold tests: PASSED\n")
}


# =============================================================================
# SECTION 2: SIMULATION HELPERS
# =============================================================================

#' Generate Simulated Trial Data
#'
#' Creates synthetic clinical trial data with known subgroup effects
#'
#' @param n Integer. Total sample size
#' @param n_factors Integer. Number of binary factors
#' @param subgroup_def Character vector. Factor names defining true subgroup
#' @param hr_subgroup Numeric. HR in true subgroup
#' @param hr_complement Numeric. HR in complement
#' @param baseline_hazard Numeric. Baseline hazard rate
#' @param censoring_rate Numeric. Proportion censored
#'
#' @return data.frame with simulated trial data
generate_trial_data <- function(
    n = 500,
    n_factors = 5,
    subgroup_def = c("F1", "F2"),
    hr_subgroup = 1.8,
    hr_complement = 0.9,
    baseline_hazard = 0.1,
    censoring_rate = 0.2
) {

  # Generate factors
  factor_names <- paste0("F", 1:n_factors)
  factors <- matrix(rbinom(n * n_factors, 1, 0.3), nrow = n)
  colnames(factors) <- factor_names

  # Treatment assignment
  treat <- rbinom(n, 1, 0.5)

  # Identify subgroup membership
  if (length(subgroup_def) > 0) {
    in_subgroup <- rowSums(factors[, subgroup_def, drop = FALSE]) == length(subgroup_def)
  } else {
    in_subgroup <- rep(FALSE, n)
  }

  # Generate survival times
  hr <- ifelse(in_subgroup, hr_subgroup, hr_complement)
  hazard <- baseline_hazard * ifelse(treat == 1, hr, 1)
  tte <- rexp(n, hazard)

  # Add censoring
  censor_time <- rexp(n, baseline_hazard * censoring_rate)
  event <- as.integer(tte <= censor_time)
  tte <- pmin(tte, censor_time)

  # Combine into data.frame
  df <- data.frame(
    id = 1:n,
    tte = tte,
    event = event,
    treat = treat,
    factors,
    flag.harm = as.integer(in_subgroup)
  )

  # Rename for ForestSearch compatibility
  names(df)[names(df) == "tte"] <- "Y"
  names(df)[names(df) == "event"] <- "Event"
  names(df)[names(df) == "treat"] <- "Treat"

  df
}


#' Generate Mock Subgroup Candidates
#'
#' Creates mock hr.subgroups data.table for testing
generate_mock_candidates <- function(df, factor_names, n_candidates = 20) {

  candidates <- list()

  for (i in 1:n_candidates) {
    # Random factor combination (1-3 factors)
    k <- sample(1:min(3, length(factor_names)), 1)
    selected <- sample(factor_names, k)

    # Create indicator
    indicator <- rep(1, length(factor_names))
    names(indicator) <- factor_names
    indicator[!factor_names %in% selected] <- 0

    # Calculate subgroup
    if (k == 1) {
      id_expr <- paste0(selected, "==1")
    } else {
      id_expr <- paste(paste0(selected, "==1"), collapse = " & ")
    }

    df_sub <- tryCatch(
      subset(df, eval(parse(text = id_expr))),
      error = function(e) NULL
    )

    if (is.null(df_sub) || nrow(df_sub) < 20) next

    # Fit Cox model
    fit <- tryCatch({
      summary(coxph(Surv(Y, Event) ~ Treat, data = df_sub, robust = FALSE))$conf.int
    }, error = function(e) NULL)

    if (is.null(fit)) next

    candidates[[length(candidates) + 1]] <- c(
      grp = i,
      K = k,
      n = nrow(df_sub),
      E = sum(df_sub$Event),
      d1 = sum(df_sub$Event[df_sub$Treat == 1]),
      m1 = NA,
      m0 = NA,
      HR = fit[1],
      `L(HR)` = fit[3],
      `U(HR)` = fit[4],
      indicator
    )
  }

  if (length(candidates) == 0) return(NULL)

  result <- data.table::as.data.table(do.call(rbind, candidates))

  # Convert numeric columns
  num_cols <- c("grp", "K", "n", "E", "d1", "HR", "L(HR)", "U(HR)")
  for (col in num_cols) {
    if (col %in% names(result)) {
      result[[col]] <- as.numeric(result[[col]])
    }
  }

  result
}


# =============================================================================
# SECTION 3: PERFORMANCE BENCHMARKS
# =============================================================================

#' Benchmark Two-Stage vs Fixed-Sample
#'
#' Compares performance and results of both algorithms
benchmark_algorithms <- function(
    n_iterations = 10,
    n_samples = 500,
    n_candidates = 15,
    n_splits_fixed = 400,
    verbose = TRUE
) {

  cat("\n")
  cat("================================================================\n")
  cat("BENCHMARK: Two-Stage Sequential vs Fixed-Sample Consistency\n")
  cat("================================================================\n")
  cat("Iterations:", n_iterations, "\n")
  cat("Sample size:", n_samples, "\n")
  cat("Candidates per iteration:", n_candidates, "\n")
  cat("Fixed splits:", n_splits_fixed, "\n")
  cat("----------------------------------------------------------------\n\n")

  results <- list()

  for (iter in 1:n_iterations) {
    if (verbose) cat("Iteration", iter, "/", n_iterations, "...\n")

    # Generate data
    set.seed(1000 + iter)
    df <- generate_trial_data(
      n = n_samples,
      n_factors = 6,
      subgroup_def = c("F1", "F2"),
      hr_subgroup = 1.6,
      hr_complement = 0.95
    )

    factor_names <- paste0("F", 1:6)
    confs_labels <- setNames(factor_names, factor_names)

    # Generate candidates
    hr.subgroups <- generate_mock_candidates(df, factor_names, n_candidates * 2)

    if (is.null(hr.subgroups) || nrow(hr.subgroups) < 5) {
      if (verbose) cat("  Skipping - insufficient candidates\n")
      next
    }

    # Filter to top candidates
    hr.subgroups <- hr.subgroups[order(-HR)][1:min(n_candidates, nrow(hr.subgroups))]

    names.Z <- factor_names
    index.Z <- hr.subgroups[, ..names.Z]

    # ----- FIXED-SAMPLE ALGORITHM -----
    t_fixed_start <- proc.time()[3]

    fixed_results <- lapply(seq_len(nrow(hr.subgroups)), function(m) {
      evaluate_subgroup_consistency(
        m = m,
        index.Z = index.Z,
        names.Z = names.Z,
        df = df,
        found.hrs = hr.subgroups,
        n.splits = n_splits_fixed,
        hr.consistency = 1.0,
        pconsistency.threshold = 0.80,
        pconsistency.digits = 2,
        maxk = 3,
        confs_labels = confs_labels,
        details = FALSE
      )
    })

    t_fixed <- proc.time()[3] - t_fixed_start
    n_fixed_pass <- sum(!sapply(fixed_results, is.null))

    # ----- TWO-STAGE ALGORITHM -----
    t_twostage_start <- proc.time()[3]

    twostage_results <- evaluate_subgroups_twostage_batch(
      found.hrs = hr.subgroups,
      index.Z = index.Z,
      names.Z = names.Z,
      df = df,
      hr.consistency = 1.0,
      pconsistency.threshold = 0.80,
      pconsistency.digits = 2,
      maxk = 3,
      confs_labels = confs_labels,
      details = FALSE,
      twostage_args = list(
        n.splits.screen = 30,
        n.splits.max = n_splits_fixed,
        batch.size = 20
      )
    )

    t_twostage <- proc.time()[3] - t_twostage_start
    n_twostage_pass <- sum(!sapply(twostage_results, is.null))

    # ----- COMPARE RESULTS -----
    # Extract Pcons values for comparison
    fixed_pcons <- sapply(fixed_results, function(x) {
      if (is.null(x)) NA else as.numeric(x["Pcons"])
    })

    twostage_pcons <- sapply(twostage_results, function(x) {
      if (is.null(x)) NA else as.numeric(x["Pcons"])
    })

    # Check agreement on pass/fail
    fixed_pass <- !is.na(fixed_pcons) & fixed_pcons >= 0.80
    twostage_pass <- !is.na(twostage_pcons) & twostage_pcons >= 0.80
    agreement <- mean(fixed_pass == twostage_pass, na.rm = TRUE)

    results[[iter]] <- list(
      n_candidates = nrow(hr.subgroups),
      t_fixed = t_fixed,
      t_twostage = t_twostage,
      speedup = t_fixed / t_twostage,
      n_fixed_pass = n_fixed_pass,
      n_twostage_pass = n_twostage_pass,
      agreement = agreement
    )

    if (verbose) {
      cat(sprintf("  Fixed: %.2fs, Two-stage: %.2fs, Speedup: %.1fx, Agreement: %.0f%%\n",
                  t_fixed, t_twostage, t_fixed/t_twostage, agreement * 100))
    }
  }

  # ----- SUMMARY -----
  if (length(results) > 0) {
    speedups <- sapply(results, `[[`, "speedup")
    agreements <- sapply(results, `[[`, "agreement")

    cat("\n")
    cat("================================================================\n")
    cat("BENCHMARK SUMMARY\n")
    cat("================================================================\n")
    cat("Successful iterations:", length(results), "\n")
    cat("Average speedup:", round(mean(speedups), 2), "x\n")
    cat("Speedup range:", round(min(speedups), 2), "x -", round(max(speedups), 2), "x\n")
    cat("Average agreement:", round(mean(agreements) * 100, 1), "%\n")
    cat("================================================================\n")
  }

  invisible(results)
}


# =============================================================================
# SECTION 4: VISUALIZATION OF ALGORITHM BEHAVIOR
# =============================================================================

#' Visualize Early Stopping Behavior
#'
#' Shows how the algorithm stops at different points based on true consistency
visualize_stopping_behavior <- function() {

  cat("\n=== Early Stopping Behavior Analysis ===\n\n")

  scenarios <- data.frame(
    true_pcons = c(0.98, 0.92, 0.88, 0.82, 0.75, 0.60),
    description = c(
      "Strong pass (0.98)",
      "Clear pass (0.92)",
      "Borderline pass (0.88)",
      "Borderline fail (0.82)",
      "Clear fail (0.75)",
      "Strong fail (0.60)"
    )
  )

  cat("Scenario Analysis (threshold = 0.85, n.splits.max = 400):\n")
  cat("----------------------------------------------------------\n")

  for (i in 1:nrow(scenarios)) {
    est <- estimate_expected_splits(
      true_pcons = scenarios$true_pcons[i],
      pconsistency.threshold = 0.85,
      n.splits.screen = 30,
      n.splits.max = 400
    )

    cat(sprintf("%-25s: Expected ~%3.0f splits, Outcome: %s\n",
                scenarios$description[i],
                est$expected_splits,
                est$outcome))
  }

  cat("----------------------------------------------------------\n")
  cat("\nKey insight: Strong/clear cases stop early, borderline cases\n")
  cat("require more evaluation. This is where efficiency gains come from.\n")
}


# =============================================================================
# SECTION 5: MAIN EXECUTION
# =============================================================================

run_all_tests <- function() {
  cat("\n")
  cat("****************************************************************\n")
  cat("*  TWO-STAGE SEQUENTIAL CONSISTENCY EVALUATION - TEST SUITE   *\n")
  cat("****************************************************************\n")

  # Run unit tests
  test_wilson_ci()
  test_early_stop_decision()
  test_calc_screen_threshold()

  # Visualize behavior
  visualize_stopping_behavior()

  # Run benchmark (reduced iterations for quick testing)
  cat("\nRunning performance benchmark...\n")
  benchmark_results <- benchmark_algorithms(
    n_iterations = 5,
    n_samples = 400,
    n_candidates = 10,
    n_splits_fixed = 300,
    verbose = TRUE
  )

  cat("\n")
  cat("****************************************************************\n")
  cat("*                    ALL TESTS COMPLETED                       *\n")
  cat("****************************************************************\n")

  invisible(benchmark_results)
}


# =============================================================================
# SECTION 6: USAGE EXAMPLES
# =============================================================================

#' Example: Basic Usage of Two-Stage Evaluation
example_basic_usage <- function() {

  cat("\n=== Example: Basic Usage ===\n\n")

  # Generate sample data
  set.seed(42)
  df <- generate_trial_data(n = 600, subgroup_def = c("F1"))

  factor_names <- paste0("F", 1:5)
  confs_labels <- setNames(factor_names, factor_names)

  # Generate candidates
  hr.subgroups <- generate_mock_candidates(df, factor_names, 30)
  hr.subgroups <- hr.subgroups[order(-HR)][1:10]

  names.Z <- factor_names
  index.Z <- hr.subgroups[, ..names.Z]

  cat("Evaluating", nrow(hr.subgroups), "candidate subgroups...\n\n")

  # Run two-stage evaluation with details
  results <- evaluate_subgroups_twostage_batch(
    found.hrs = hr.subgroups,
    index.Z = index.Z,
    names.Z = names.Z,
    df = df,
    hr.consistency = 1.0,
    pconsistency.threshold = 0.80,
    pconsistency.digits = 2,
    maxk = 3,
    confs_labels = confs_labels,
    details = TRUE,
    twostage_args = list(
      n.splits.screen = 30,
      n.splits.max = 400
    )
  )

  # Summarize results
  n_passed <- sum(!sapply(results, is.null))
  cat("\n\nSubgroups passing consistency:", n_passed, "/", length(results), "\n")
}


#' Example: Integration with forestsearch workflow
example_forestsearch_integration <- function() {

  cat("\n=== Example: ForestSearch Integration ===\n\n")

  cat("To use two-stage evaluation in your ForestSearch workflow:\n\n")

  cat('# Option 1: Use the new wrapper function directly
result <- subgroup.consistency.twostage(
  df = df,
  hr.subgroups = fs_candidates$hr.subgroups,
  hr.threshold = 1.25,
  hr.consistency = 1.1,
  pconsistency.threshold = 0.90,
  n.splits = 400,                    # This becomes n.splits.max
  maxk = 2,
  Lsg = length(factor_names),
  confs_labels = confs_labels,
  sg_focus = "maxSG",
  # Two-stage specific options:
  use.twostage = TRUE,               # Enable two-stage (default)
  n.splits.screen = 30,              # Stage 1 splits
  batch.size = 20,                   # Stage 2 batch size
  early.stop.conf = 0.95,            # Confidence for stopping
  details = TRUE
)

# Option 2: Modify existing subgroup.consistency call
# Replace the internal evaluate_subgroup_consistency calls with
# evaluate_consistency_twostage for improved performance.
')
}


# Uncomment to run:
# run_all_tests()
# example_basic_usage()
# example_forestsearch_integration()
